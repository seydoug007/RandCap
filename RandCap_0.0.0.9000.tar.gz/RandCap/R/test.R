#
# library(RandCap)
# library(tidyverse)
# rand_object<-RandCapGen(
#   n=100,
#   arms = c("A","B"),
#   block_sizes = 2,
#   strat_vars = list(sex=c(1,2),
#                     center=c(700:705))
# )
#
# rand_object$tables$simplified_dataset%>%head()%>%View()
#
# RandCapBalance(rand_object)
