## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
devtools::install_github("seydoug007/RandCap")

## -----------------------------------------------------------------------------
library(RandCap)

## -----------------------------------------------------------------------------
rand_dev_list <- RandCapGen(
  n = 100,
  block_sizes = c(2, 4),
  arms = c("A", "B"),
  seed = 1234
)

## -----------------------------------------------------------------------------
rand_list_strat <- RandCapGen(
  n = 100,
  block_sizes = c(2, 4),
  arms = c("A", "B"),
  strat_vars = list(Sex = c("M", "F"), AgeGroup = c("Y", "O")),
  strat_vars_prefix = list(Sex = "SEX_", AgeGroup = "AGE_"),
  seed = 5678
)

## -----------------------------------------------------------------------------
head(rand_list_strat$tables$full_dataset)


## -----------------------------------------------------------------------------
head(rand_list_strat$tables$simplified_dataset)

## -----------------------------------------------------------------------------
prod_list <- RandCapProd(randomization_object = rand_list_strat, seed = 9876)


## -----------------------------------------------------------------------------
colnames(rand_list_strat$tables$simplified_dataset) <- c("rando_bras", "Rando_Sex", "Rando_AgeGroup")

head(rand_list_strat$tables$simplified_dataset)

## -----------------------------------------------------------------------------
RandCapBalance(
  randomization_object = rand_list_strat)

## -----------------------------------------------------------------------------

RandCapSettings(rand_obj = rand_list_strat)

## -----------------------------------------------------------------------------
RandCapTable(
  randomization_object = rand_list_strat,
  save_for_REDCap = TRUE,
  save_random_table = TRUE
)

## -----------------------------------------------------------------------------
rand_custom_ratio <- RandCapGen(
  n = 300,
  block_sizes = c(5, 10),
  arms = c("A", "B","C"),
  ratio = c(1,2,2),
  seed = 3456
)

## -----------------------------------------------------------------------------
RandCapBalance(rand_custom_ratio)

